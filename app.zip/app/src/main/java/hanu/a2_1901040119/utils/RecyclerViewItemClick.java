package hanu.a2_1901040119.utils;

import android.view.View;

public interface RecyclerViewItemClick {
    public void onItemClick(int position, View v);
}
