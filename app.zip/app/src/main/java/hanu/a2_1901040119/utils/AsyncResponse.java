package hanu.a2_1901040119.utils;

public interface AsyncResponse {
    public void onTaskCompleted();
}
